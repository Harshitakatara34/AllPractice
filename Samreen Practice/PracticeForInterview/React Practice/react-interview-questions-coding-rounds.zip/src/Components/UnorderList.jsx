import Unorder from "./Unorder";

function UnorderList() {
  const elements = ["bag", "box", "pen"];

  return (
    <div>
      <Unorder elements={elements} />
    </div>
  );
}

export default UnorderList;
