export function SimpleCalculator() {
  return <div></div>;
}
