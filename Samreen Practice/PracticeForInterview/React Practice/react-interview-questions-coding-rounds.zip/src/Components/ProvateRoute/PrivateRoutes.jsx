// import {Navigate} from 'react-router-dom'
export function PrivateRoutes({ children }) {
  // let data = 5;
  // if(data.length>=0){
  //  return <Navigate to='/login'/>
  // }
  // return  {children}
}
