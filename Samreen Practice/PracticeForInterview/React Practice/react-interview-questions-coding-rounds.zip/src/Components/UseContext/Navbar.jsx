const Navbar = () => {
  return (
    <div style={{ display: "flex", justifyContent: "space-around" }}>
      <h3>Home</h3>
      <h3>About</h3>
      <h3>Contact</h3>
    </div>
  );
};
export default Navbar;
